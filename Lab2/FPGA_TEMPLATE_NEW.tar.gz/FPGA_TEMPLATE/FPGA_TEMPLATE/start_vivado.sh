
vivado -mode gui -source shell.tcl &
